<?php include 'includes/header.php'; ?>

<div id="wrapper">

	<!-- Navigation -->
	<?php include 'includes/navigation.php'; ?>


	<div id="page-wrapper">

		<div class="container-fluid">

			<!-- Page Heading -->
			<div class="row">

					<h1 class="page-header">
						Welcome to the Administration Panel
					</h1>
        <table class="table table-bordered table-striped table-hover">
		  <thead>
		    <th>Post Id</th>
		    <th>Post Title</th>
			<th>Post Author</th>
			<th>Post Category</th>
			<th>Post Status</th>
			<th>Post Images</th>
			<th>Post Content</th>
			<th>Post Date</th>
			<th>Post Comment</th>
			<th>Post Views</th>
			<th>Approve Post</th>
			<th>Unapprove Post</th>
			<th>Edit</th>
			<th>Delete</th>
			<th></th>
			
		  </thead>
		  <tbody>
	        <?php show_posts(); ?> 	  
		  
		  </tbody>
		
		</table>

<?php 
    if (isset($_GET['source'])) {
	    $source = $_GET['source'];
		
    if (!empty($source)) {
	switch($source) {
	  case 'add_new':
		include "includes/add_post.php";
		break;
	  default:
        include "posts.php";
        break;		
    }
	}
	/*	if (!empty($source)) {} */
	
	}
?>
</div>
				</div>


			</div>

			<!-- /.row -->

		</div>
		<!-- /.container-fluid -->

	</div>
	<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script src="bootstrap/js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
